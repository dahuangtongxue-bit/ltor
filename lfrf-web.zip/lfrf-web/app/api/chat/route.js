import Anthropic from '@anthropic-ai/sdk';

// 简单的内存级限流（serverless 重启会清空，够小规模用）
const usageMap = new Map(); // ip -> { count, resetAt }
const DAILY_LIMIT = parseInt(process.env.DAILY_LIMIT_PER_IP || '20'); // 每 IP 每日最多 20 次调用

function getIp(req) {
  return req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()
    || req.headers.get('x-real-ip')
    || 'unknown';
}

function checkRateLimit(ip) {
  const now = Date.now();
  const record = usageMap.get(ip);
  if (!record || now > record.resetAt) {
    usageMap.set(ip, { count: 1, resetAt: now + 24 * 60 * 60 * 1000 });
    return { ok: true, remaining: DAILY_LIMIT - 1 };
  }
  if (record.count >= DAILY_LIMIT) {
    return { ok: false, remaining: 0, resetAt: record.resetAt };
  }
  record.count += 1;
  return { ok: true, remaining: DAILY_LIMIT - record.count };
}

export async function POST(req) {
  try {
    const body = await req.json();
    const { password, model, system, message, maxTokens } = body;

    // 密码门
    if (process.env.ACCESS_PASSWORD && password !== process.env.ACCESS_PASSWORD) {
      return Response.json({ error: { type: 'unauthorized', message: '访问密码错误' } }, { status: 401 });
    }

    // 限流
    const ip = getIp(req);
    const rl = checkRateLimit(ip);
    if (!rl.ok) {
      const hoursLeft = Math.ceil((rl.resetAt - Date.now()) / (60 * 60 * 1000));
      return Response.json({
        error: { type: 'rate_limit', message: `你今天已用完 ${DAILY_LIMIT} 次额度，${hoursLeft} 小时后重置` }
      }, { status: 429 });
    }

    if (!process.env.ANTHROPIC_API_KEY) {
      return Response.json({ error: { type: 'config_error', message: '服务端未配置 API key' } }, { status: 500 });
    }

    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const response = await client.messages.create({
      model: model || 'claude-sonnet-4-5',
      max_tokens: maxTokens || 1500,
      system,
      messages: [{ role: 'user', content: message }],
    });

    const text = response.content.map(b => b.type === 'text' ? b.text : '').join('\n');
    return Response.json({ text, remaining: rl.remaining });

  } catch (err) {
    console.error('API error:', err);
    return Response.json({
      error: {
        type: err.type || 'unknown',
        message: err.message || '未知错误',
        status: err.status,
      }
    }, { status: err.status || 500 });
  }
}

export const runtime = 'nodejs';
export const maxDuration = 60; // Vercel: 允许 60 秒（hobby 计划上限）
