# 左脚踩右脚 · 部署指南

让 3-5 个朋友能真实测试你的产品。预计 **30 分钟** 完成部署。

---

## 总览

```
朋友的浏览器 ─→ Vercel 上的网站 ─→ 你的后端 API（带密码+限流） ─→ Anthropic API
                                                                ↑
                                                       你的 API key 安全放在这里
```

为什么不直接前端调用 Anthropic API？因为那样必须把 API key 暴露在前端，等于公开你的钱包。

---

## 准备工作（5 分钟）

需要先注册三个账号（都免费）：

1. **GitHub** — https://github.com/signup
2. **Vercel** — https://vercel.com/signup（用 GitHub 账号一键登录）
3. **Anthropic API** — https://console.anthropic.com/
   - 注册后进入 Billing 充值 $10-20（不能用 Pro 订阅，是单独的 API 计费）
   - 在 Settings → Limits 里设个月度上限，比如 $30，防止意外烧钱
   - 在 API Keys 里创建一个 key，复制保存（只显示一次）

---

## 部署步骤

### 第 1 步：把代码推到 GitHub

```bash
# 在这个项目目录里
cd lfrf-web
git init
git add .
git commit -m "initial commit"

# 去 GitHub 创建一个新仓库（不用 README），然后：
git remote add origin https://github.com/你的用户名/lfrf-web.git
git branch -M main
git push -u origin main
```

> 仓库设为 Private（私有），里面虽然没 API key（被 .gitignore 排除了），但代码不公开也没坏处。

### 第 2 步：在 Vercel 部署

1. 打开 https://vercel.com/new
2. 选择刚才推上去的 GitHub 仓库 → 点 Import
3. 在 **Environment Variables** 区域加 3 个变量：
   - `ANTHROPIC_API_KEY` = 你刚才在 Anthropic console 拿到的 key
   - `ACCESS_PASSWORD` = 你自己定一个密码，比如 `aikingdom2026`，朋友登录用
   - `DAILY_LIMIT_PER_IP` = `20`（每人每天最多 20 次 API 调用，可调）
4. 点 **Deploy**

等 1-2 分钟，部署成功后会给你一个网址，类似 `https://lfrf-web-xxxx.vercel.app`。

### 第 3 步：发给朋友

把 **网址 + 密码** 一起发给朋友。让他们打开网址，输入密码即可使用。密码会保存在浏览器，下次自动登录。

---

## 给朋友的使用说明（建议发这段）

```
帮我测一下我做的产品「左脚踩右脚」🦶

地址：https://你的-vercel-地址
密码：你的密码

产品做什么：你提一个值得推敲的问题（比如复杂决策、技术选型、深度分析），
两个 AI 会自动互相挑刺打磨。你可以随时作为裁判介入，引导讨论方向。

测试时希望你关注：
1. 提炼出的"第一性目标"是否准确
2. 审查者 B 找的问题是否真的有价值，还是吹毛求疵
3. 修订后的答案是否真的变好了
4. 整个流程让你觉得是值得 vs 浪费时间

每人每天 20 次调用额度（一次完整 review 大约 4-6 次调用）。
反馈直接微信发我。
```

---

## 成本控制

- 一轮完整 review（主答 + 审查 + 修订 + 综合）约 **$0.10-0.30**（Opus 主答较贵）
- 你 5 个朋友 × 各试 5 轮 ≈ $5-10
- 建议：
  - **在 Anthropic console 设置月度上限**（$20-30）作为兜底
  - 看到费用快爆，登录 Vercel 把 Environment Variable 里的 `DAILY_LIMIT_PER_IP` 改小，redeploy 即可生效
  - 测试完想关闭：去 Vercel project settings → Domains → 点 disable 那个域名，或者干脆 delete project

---

## 本地开发（可选）

如果你想先在自己电脑上跑起来调试：

```bash
cd lfrf-web
npm install
cp .env.example .env.local
# 编辑 .env.local 填入你的 API key 和密码
npm run dev
```

打开 http://localhost:3000

---

## 文件结构

```
lfrf-web/
├── app/
│   ├── api/chat/route.js   ← 后端代理（密码校验、限流、调 Anthropic API）
│   ├── layout.js
│   ├── page.js
│   └── globals.css
├── components/
│   └── LeftFootRightFoot.jsx  ← 主组件（从 artifact 改造而来）
├── package.json
├── next.config.js
├── tailwind.config.js
├── postcss.config.js
└── .env.example
```

---

## 后续可能想加的

测试一段时间后如果反馈不错，下一步可以：
- 把密码门改成"邀请码"，每人独立配额
- 加 Vercel KV 存储用户会话历史
- 加更精细的用量监控仪表盘
- 接入 OpenAI / DeepSeek 做真正的跨家族对抗

但 MVP 阶段先验证产品价值。这个版本已经足够发给朋友测试了。
